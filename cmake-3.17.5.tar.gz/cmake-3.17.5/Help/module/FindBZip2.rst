.. cmake-module:: ../../Modules/FindBZip2.cmake
